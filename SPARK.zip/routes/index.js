//import {PythonShell} from 'python-shell';
(function(){
var childProcess = require("child_process");
var oldSpawn = childProcess.spawn;
function mySpawn(){
        console.log('spawn called');
        console.log(arguments);
var result = oldSpawn.apply(this, arguments);
return result;
}
    childProcess.spawn = mySpawn;
})();
console.log( process.env.PATH );


var express = require('express');
var router = express.Router();
var videoDir = './public/videos';
var imageDir = './assets/image';
var fs = require('fs');
const path = require('path');
var multer = require('multer');

//var PythonShell = require('python-shell');
//var pyshell = new PythonShell('test.py');

let {PythonShell} = require('python-shell');
//console.log(PythonShell);

PythonShell.run('./engine/test.py', null, function (err, results) {
  if (err) throw err;
  console.log('result: %j', results);
});

var storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, 'public/videos') // cb 콜백함수를 통해 전송된 파일 저장 디렉토리 설정
	},
	filename: function (req, file, cb) {
		cb(null, file.originalname) // cb 콜백함수를 통해 전송된 파일 이름 설정
	}
})
var upload = multer({ storage: storage })
//const upload = multer({ dest: 'assets/video', limits: { fileSize: 5 * 1024 * 1024 } });

/* GET home page. */
router.get('/', function(req, res, next) {
	console.log("sdfsdfs");
	var videolist = fs.readdirSync(videoDir);
	console.log(videolist);
	//videolist = filelist;

	res.render('./index', {
		'title': 'Express',
		videoList: videolist,
		listsize: videolist.length
	});
});

router.post('/upload', upload.single('userfile'), function(req, res){
  //res.send('Uploaded! : '+req.file); // object를 리턴함
  console.log(req.file); // 콘솔(터미널)을 통해서 req.file Object 내용 확인 가능.
  res.redirect('/');
});

module.exports = router;
