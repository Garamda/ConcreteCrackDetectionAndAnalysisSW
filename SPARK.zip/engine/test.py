import sys


print("111111")